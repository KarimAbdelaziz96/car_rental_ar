class Constants {
  static var x = 'http://192.168.68.133/class-api/';
}
